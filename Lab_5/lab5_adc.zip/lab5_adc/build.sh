echo "Building file as: adc_example"
g++ adc_example.cpp SPIDevice.cpp BusDevice.cpp -o adc_example
